public class Booking {
    private String bookingReference;
    private User madeBy;
    private Ticket[] canHave;
    
    public boolean addBooking() { return false; }
    public boolean editBooking() { return false; }
    public boolean removeBooking() { return false; }
    public void queryBookings() {}
    public String getBooking() { return null; }
    public String getReference() { return null; }
    public void setReference(String str) {}
}