public class Student extends Person {
    private int studentNumber;
    private int averageMark;

    public boolean isEligibleToEnroll() {
        // Implementation not required
        return false;
    }

    public int getSeminarsTaken() {
        // Implementation not required
        return 0;
    }
    
    // getters and setters for studentNumber, averageMark
    // ...
}