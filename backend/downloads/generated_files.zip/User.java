public class User {
    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private String address;
    private String town;
    private String county;
    private String postcode;
    private String email;
    
    public boolean addUser() { return false; }
    public boolean editUser() { return false; }
    public boolean removeUser() { return false; }
    public String getUsername() { return null; }
    public void setUsername(String str) {}
    public void loadUsers() {}
    public void queryUsers() {}
    public boolean loggedIn() { return false; }
}