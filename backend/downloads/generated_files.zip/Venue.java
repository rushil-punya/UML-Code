public class Venue {
    private String venueName;
    private String venueLocation;
    private Show[] canBeInShows;
    
    public boolean addVenue() { return false; }
    public boolean editVenue() { return false; }
    public boolean removeVenue() { return false; }
    public String getVenue() { return null; }
    public void setVenue(String str) {}
    public String getLocation() { return null; }
    public void setLocation(String str) {}
}