public class Person {
    private String name;
    private String phoneNumber;
    private String emailAddress;
    private Address address; // Association with Address

    public void purchaseParkingPass() {
        // Implementation not required
    }
    
    // getters and setters for name, phoneNumber, emailAddress, address
    // ...
}