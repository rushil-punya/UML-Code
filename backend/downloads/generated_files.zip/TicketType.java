public class TicketType {
    private String ticketType;
    private Ticket canInclude;
    
    public boolean addTicketType() { return false; }
    public boolean editTicketType() { return false; }
    public boolean removeTicketType() { return false; }
    public String getTicketType() { return null; }
    public void setTicketType(String str) {}
}