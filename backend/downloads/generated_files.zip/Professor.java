public class Professor extends Person {
    private int salary;
    private int staffNumber;
    private int yearsOfService;
    private int numberOfClasses;
    
    // Relationship with Student (supervision)
    private List<Student> supervisedStudents;

    public Professor() {
        supervisedStudents = new ArrayList<>();
    }
    
    // Method to add a student to the supervision list
    public void addSupervisedStudent(Student student) {
        supervisedStudents.add(student);
    }
    
    // Method to get the list of supervised students
    public List<Student> getSupervisedStudents() {
        return supervisedStudents;
    }

    // getters and setters for salary, staffNumber, yearsOfService, numberOfClasses
    // ...
}