public class Show {
    private String showName;
    private Seat[] canBeInSeats;
    private Venue canHost;
    
    public boolean addShow() { return false; }
    public boolean editShow() { return false; }
    public boolean removeShow() { return false; }
    public String getShow() { return null; }
    public void setShow(String str) {}
}