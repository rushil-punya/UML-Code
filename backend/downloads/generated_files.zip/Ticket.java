public class Ticket {
    private String ticketName;
    private Booking includedIn;
    private TicketType canHaveType;
    
    public boolean addTicket() { return false; }
    public boolean editTicket() { return false; }
    public boolean removeTicket() { return false; }
    public String getTicketName() { return null; }
    public void setTicketName(String str) {}
    public void queryTickets() {}
}