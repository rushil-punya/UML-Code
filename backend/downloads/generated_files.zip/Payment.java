public class Payment {
    private String invoiceNumber;
    private String paymentName;
    
    public boolean addPayment() { return false; }
    public boolean editPayment() { return false; }
    public boolean removePayment() { return false; }
    public String getInvoiceNumber() { return null; }
    public void setInvoiceNumber(String str) {}
}