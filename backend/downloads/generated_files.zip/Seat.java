public class Seat {
    private String seatName;
    private Show canBeIn;
    
    public boolean addSeat() { return false; }
    public boolean editSeat() { return false; }
    public boolean removeSeat() { return false; }
    public String getSeat() { return null; }
    public void setSeat(String str) {}
}